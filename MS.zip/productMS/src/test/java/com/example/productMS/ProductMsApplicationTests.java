package com.example.productMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
