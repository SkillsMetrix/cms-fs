package com.example.app_registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
