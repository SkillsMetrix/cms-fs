

export const ActionTypes={
    SET_PRODUCT: "SET_PRODUCT",
    SELECTED_PRODUCT:"SELECTED_PRODUCT"
    
}