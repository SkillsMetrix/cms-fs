import { ActionTypes } from "../constants/action-types"

// its loading the data from productlisting and add the products into store
export const setProducts=(products) =>{
    return {
        type:ActionTypes.SET_PRODUCT,
        payload: products
    }
}
export const selectedProduct=(product) =>{
    return{
        type:ActionTypes.SELECTED_PRODUCT,
        payload:product
    }
}