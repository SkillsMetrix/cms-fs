import React from 'react';

function Header(props) {
    return (
        <div className='ui fixed menu'>
            <div className='ui container center'>
            <h2>UserShop Inc Global</h2>
        </div>
        </div>
        
    );
}

export default Header;