import React from 'react';

function ProductDetails(props) {
    return (
        <div>
            ProductDetails
        </div>
    );
}

export default ProductDetails;