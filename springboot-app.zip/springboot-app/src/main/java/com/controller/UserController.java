package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.service.annotation.GetExchange;

import com.model.Users;
import com.service.UserService;

 
@Controller
@RequestMapping("/userapp")
public class UserController {
	
	@Autowired
	private UserService userService;
	@GetMapping("/register")
	public String loadUserForm(Model model) {
		model.addAttribute("user",new Users());
		return "userform";
	}
	@PostMapping("/register")
	 
	public String addUser(@ModelAttribute Users users,Model model) {
		userService.addUser(users);
		model.addAttribute("user",new Users());
		return "login";
	}
	@GetMapping("/login")
	public String loadLoginForm(Model model) {
		model.addAttribute("user",new Users());
		return "login";
	}
	@PostMapping("/login")
	  
	public String loginValidate(@ModelAttribute Users users) {
	if(	userService.loginValidate(users)) {
		return "redirect:/userapp/loadall";
	}
		return "login Failed....!";
	}
	
	@GetMapping("/loadall")
	
	public String loadall(Model model) {
		model.addAttribute("user",userService.loadAll());
		return "loadall";
	}
	
@GetMapping("/deleteuser/{email}")
	@ResponseBody
	public String loadall(@PathVariable String email) {
		 if(userService.deleteUser(email)) {
			 return "user deleted";
		 }
		return "user not found";
	}
	
}
