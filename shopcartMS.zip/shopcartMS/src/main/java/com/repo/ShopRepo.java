package com.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.entity.CartEntity;
import com.entity.Product;
@Repository
public interface ShopRepo extends CrudRepository<CartEntity, Long> {
	List<CartEntity> findByUserId(Long userId);

}
