package com.service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.entity.CartEntity;
import com.entity.Product;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.ShoppingCartRequest;
import com.model.ShoppingCartResponse;
import com.repo.ShopRepo;
@Service
public class ShoppingService {
	@Autowired
	private ShopRepo repo;
	@Autowired
	private RestTemplate template;
	
	public ShoppingCartResponse processAndSend(Long userId, List<ShoppingCartRequest> shoppingCartRequests) {
		
		ObjectMapper mapper= new ObjectMapper();
		String productServiceURL="http://productMS/products/getproduct/"+
		shoppingCartRequests.stream()
		.map(e -> String.valueOf(e.getProductId()))
		.collect(Collectors.joining(","));
		Product[] productArray=template.getForObject(productServiceURL, Product[].class);
		List<Product> psl= Arrays.asList(productArray);
		double  totalCost=0.0;
		for(Product p: psl) {
			for(ShoppingCartRequest cr: shoppingCartRequests) {
				if(p.getProductID().equals(cr.getProductId())) {
					p.setQuantity(cr.getQuantity());
					totalCost +=p.getAmount()*cr.getQuantity();
				}
			}
		}
		CartEntity cartEntity=null;
		try {
			cartEntity=CartEntity.builder()
					.userId(userId)
					.cartId((long)(Math.random()*Math.pow(10, 10)))
					.totalItems(psl.size())
					.totalCosts(totalCost)
					.products(mapper.writeValueAsString(psl)).build();
			cartEntity=repo.save(cartEntity);
		}catch (Exception e) {}
		
		return ShoppingCartResponse.builder() 
				.cartId(cartEntity.getCartId())
				.userId(cartEntity.getUserId())
				.totalItems(cartEntity.getTotalItems())
				.totalCosts(cartEntity.getTotalCosts())
				.build();
		
		
	}

 	 
}
