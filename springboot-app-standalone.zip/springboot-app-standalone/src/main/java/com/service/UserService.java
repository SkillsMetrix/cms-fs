package com.service;

import java.util.List;

import com.model.Users;

public interface UserService {
	public Users addUser(Users users);
	public boolean loginValidate(Users users);
	public List<Users> loadAll();
	public boolean deleteUser(String email);
	public boolean findUser(String email);

}
