package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Users;

@Service
public class UserServiceImpl implements UserService{

	List<Users> userList= new ArrayList<Users>();
	@Override
	public Users addUser(Users users) {
		 userList.add(users);
		 System.out.println(userList);
		 return users;
	}
	@Override
	public boolean loginValidate(Users users) {
		 boolean valid= userList.stream()
				 .anyMatch(u-> u.getUserName().equalsIgnoreCase(users.getUserName()) 
						 && u.getPassword().equals(users.getPassword()));
		 if(valid) {
			 return true;
		 }
		return false;
	}
	@Override
	public List<Users> loadAll() {
		// TODO Auto-generated method stub
		return userList;
	}
	@Override
	public boolean deleteUser(String email) {
		for(Users list: userList) {
			if(list.getEmail().equalsIgnoreCase(email)) {
				userList.remove(list);
			}
			return true;
		}
		return false;
	}
	@Override
	public boolean findUser(String email) {
		for(Users list: userList) {
			if(list.getEmail().equalsIgnoreCase(email)) {
				return true;
			}
			
		}
		return false;
	}
	

}
