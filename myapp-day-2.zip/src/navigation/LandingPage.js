import React from 'react';
import NavBar from './NavBar';
import { useRoutes } from 'react-router-dom';
import { routes } from '../routes';

function LandingPage(props) {
    const element= useRoutes(routes)
    return (
        <div>
            <NavBar/>
            <hr/>
            {element}
        </div>
    );
}

export default LandingPage;