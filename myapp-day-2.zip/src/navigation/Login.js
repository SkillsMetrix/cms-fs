import React, { useState } from "react";
import { useNavigate } from 'react-router-dom'
import loginCheck from "../services/Loginservice";
function Login(props) {
    const navigate=useNavigate()
   
   
 const [uname,setUname]=useState('')
  const [pass,setPass]=useState('')
  const validate = (e) => {
    e.preventDefault()
      const userStored= JSON.parse( localStorage.getItem("udata")) || []
      console.log(userStored);
      
       
       if(userStored.uname ===uname && userStored.pass===pass ){
        loginCheck()
        alert('authorized')
         navigate("/userdetails")
       }else{
        alert('unauthorized')
       }
     
        }
  return (
    <div className="container">
      <div class="card">
        <div class="card-header">User Login Form</div>
        <div class="card-body">
          <form onSubmit={validate}>
            UserName: <input type="text"  name="uname"  onChange={(e)=> setUname(e.target.value)}/> &nbsp; 
            Password:<input type="password"  name="pass" onChange={(e)=> setPass(e.target.value)}/>
           
            &nbsp;
            <button className="btn btn-primary">Login</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
