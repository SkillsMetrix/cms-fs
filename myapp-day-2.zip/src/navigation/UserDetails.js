

import React, { useEffect, useState } from 'react';
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import DataShow from '../components/DataShow';
import loginCheck from '../services/Loginservice';
const URL='https://jsonplaceholder.typicode.com/users'
function UserDetails(props) {
const [users,setUsers]= useState([])
const navigate=useNavigate()
    useEffect(()=>{
        let check= loginCheck()
        if(check === false){
            navigate("/login")
        }
        axios.get(URL)
        .then((res) => res.data)
        .then((data)=>{
           
            setUsers(data)
            
        })
    },[])

    return (
        <div>
           <DataShow data={users}/>
        </div>
    );
}

export default UserDetails;