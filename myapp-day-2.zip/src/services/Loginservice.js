 
function loginCheck(isAllowed=false) {
    
    if(isAllowed=false){
        alert('Unauthorized access...!')
    }else{
        isAllowed=true
    }
    return isAllowed
}

export default loginCheck;