import React, { useState } from "react";
import { useNavigate } from 'react-router-dom'
function UserRegistration(props) {

  const navigate = useNavigate()
  // array to store the userForm
  const [users, setUsers] = useState([]);

  const handleChange=(e) =>{
    setUsers({...users,[e.target.name]:e.target.value})
  }
  const addUser = (e) => {
    e.preventDefault()
      localStorage.setItem("udata",JSON.stringify(users))
      navigate("/login")
        }
  return (
    <div className="container">
      <div class="card">
        <div class="card-header">User Registration Form</div>
        <div class="card-body">
          <form onSubmit={addUser}>
            UserName: <input type="text"  name="uname"  onChange={handleChange}/> &nbsp; 
            Password:<input type="password"  name="pass" onChange={handleChange}/>
            &nbsp; Email: <input type="email"  name="email" onChange={handleChange}/>
            &nbsp; City : <input type="text"  name="city"  onChange={handleChange}/>
            &nbsp;
            <button className="btn btn-primary">Register</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default UserRegistration;
