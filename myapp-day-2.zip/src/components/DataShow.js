


import React from 'react';

function DataShow(props) {
    return (
        <div>
           
        <table class="table">
           
  <thead>
    <tr>
       
      <th scope="col">UserName</th>
      <th scope="col">Email</th>
      <th scope="col">Username</th>
    </tr>
  </thead>
  <tbody>
     {props.data.map((user)=> (
 <tr>
     
       
      <td> {user.name}</td>
      <td>{user.email} </td>
      <td>{user.username} </td>
     
      
      
    </tr>   
     ))}
   
    </tbody>
    </table> 
        </div>
    );
}

export default DataShow;