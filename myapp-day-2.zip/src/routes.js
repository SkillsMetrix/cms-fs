import UserRegistration from "./components/UserRegistration";
import Login from "./navigation/Login";
import UserDetails from "./navigation/UserDetails";



export const routes=[
    {path:'/', element:<Login/>},
     {path:'/register', element:<UserRegistration/>},
      {path:'/userdetails', element:<UserDetails/>}
]