import logo from './logo.svg';
import './App.css';
import MainApp from './components/MainApp';
import LandingPage from './navigation/LandingPage';

function App() {
  return (
    <div className="App">
      
    <LandingPage/>
    </div>
  );
}

export default App;
