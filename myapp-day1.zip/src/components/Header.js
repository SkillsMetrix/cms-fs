

function Header(props){
    return(
        <div>
            <p>{props.hm}</p>
        </div>
    )
}
export default Header