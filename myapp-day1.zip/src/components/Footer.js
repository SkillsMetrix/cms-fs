

function Footer(props){
    return(
        <div>
           <ul>
          {props.data.map((users)=> (
            <li>{users}</li>
          ))}
           </ul>
        </div>
    )
}
export default Footer