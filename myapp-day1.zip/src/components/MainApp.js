import Footer from "./Footer"
import Header from "./Header"
import UserRegistration from "./UserRegistration"



function MainApp(){
const headerMessage='welcome to header'
const usersData=['admin','manager','qa']
    return(

        <div>
            {/* <Header hm={headerMessage}/> */}
          <UserRegistration/>
            {/* <Footer data={usersData}/> */}
        </div>
    )
}
export default MainApp