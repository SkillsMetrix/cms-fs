import React, { useState } from "react";

function UserRegistration(props) {
  // array to store the userForm
  const [users, setUsers] = useState([]);

  const [uname, setUname] = useState("");
  const [pass, setPass] = useState("");
  const [email, setEmail] = useState("");
  const [city, setCity] = useState("");
  const addUser = (e) => {
    e.preventDefault();
  };
  return (
    <div className="container">
      <div class="card">
        <div class="card-header">User Registration Form</div>
        <div class="card-body">
          <form onSubmit={addUser}>
            UserName: <input type="text" value={uname} /> &nbsp; Password:{" "}
            <input type="password" value={pass} />
            &nbsp; Email: <input type="password" value={email} />
            &nbsp; City : <input type="text" value={city} />
            &nbsp;
            <button className="btn btn-primary">Register</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default UserRegistration;
